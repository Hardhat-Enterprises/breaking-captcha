def main(event, context):
    print("working")